//
//  ViewController_C.swift
//  pickapath
//
//  Created by Christian Jurt on 2017-11-28.
//  Copyright © 2017 Christian Jurt. All rights reserved.
//

import UIKit

class ViewController_C: UIViewController {
    
    @IBOutlet weak var page_title: UINavigationItem!
    @IBOutlet weak var restartButton: UINavigationItem!
    @IBOutlet weak var page_text: UITextView!
    
    
    var currentPage: Page? = Page()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
            page_title.title = "Page \(currentPage!.pageNumber ?? 3)"
            page_text.text = currentPage?.pageText
        }

    @IBAction func restartActionButton(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }

}
