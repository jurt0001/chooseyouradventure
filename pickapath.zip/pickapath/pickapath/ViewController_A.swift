//
//  ViewController_A.swift
//  pickapath
//
//  Created by Christian Jurt on 2017-11-28.
//  Copyright © 2017 Christian Jurt. All rights reserved.
//

import UIKit

class ViewController_A: UIViewController {
    
    
    @IBOutlet weak var page_title: UINavigationItem!
    @IBOutlet weak var pageButtonA: UIBarButtonItem!
    @IBOutlet weak var pageButtonB: UIBarButtonItem!
    @IBOutlet weak var page_text: UITextView!
    
        var page1: Page? = Page()
        var page2: Page? = Page()
        var page3: Page? = Page()
        var page4: Page? = Page()
        var page5: Page? = Page()
        var page6: Page? = Page()
        var page7: Page? = Page()
        var currentPage: Page? = Page()
    
    var myPageButtonA: String = ""
    var myPageButtonB: String = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()

                page1?.pageNumber = 1
                page2?.pageNumber = 2
                page3?.pageNumber = 3
                page4?.pageNumber = 4
                page5?.pageNumber = 5
                page6?.pageNumber = 6
                page7?.pageNumber = 7
        
                page1?.pageText = "Your phone buzzes relentlessly with Twitter and Facebook feed updates – zombies are flooding the streets of Ottawa!  You grab your backpack.  Is the first thing you look for: * a weapon to defend yourself? (Go to page object 2) * food and supplies?  Who knows when you'll be able to have another good meal? (Go to page object 3)"
        
                page2?.pageText = "You rush to the basement and find a baseball bat, a chainsaw, and a paintball gun.  You grab the bat, a few snacks, and consider your options.  Do you: * board up the house and try wait out the invasion? (Go to page object 4) * run to the mall?  It kind-of worked in that movie.   (Go to page object 5)"
        
                page3?.pageText = "You pack a few sets of clothes, and as much food as your bag can hold.  Looking cautiously outside the window, the streets seem empty.  Do you: * make a run for the car?  If you make it out of town, you may be able to buy yourself some time. (Go to page object 6) * call your buddies and set up a rendezvous?  You'll be safer in numbers. (Go to page object 7)"
        
                page4?.pageText = "You tear apart your furniture and board up all of the windows and doors.  Sitting at the top of the stairs, you wait for the inevitable.  Several hours later the doorbell rings.  You cautiously peer outside, and see your friends waiting at the door.  They laugh hysterically as you rip down the barricade.  “Don't you know what day it is?” one asks you.  April 1st. Ah well - at least you're prepared."
        
                page5?.pageText = "You grab your bag, lock up the house, and run down the street towards the mall.  Off in the distance, you see some lumbering silhouettes.  As you reach the doors, you notice that a few others seem to have had the same idea.  Once inside, the doors are locked, and you claim one of the big showroom beds and a 60” LED TV as your own.  Who knows how long you'll have to wait?"
        
                page6?.pageText = "Your bags are packed, and you get the keys to the car.  You're glad you filled up the tank on your way home from work last night.  After making sure the coast is clear, you lock the door and dash to the car.  Your parents are out of the country – thankfully – which means that the boat should be locked up along the river.  You'll be safe there; everyone knows that zombies can't swim... right?"
        
                page7?.pageText = "You set your Facebook status to “meet up at 45.216867, -75.962180 ”, stopping only briefly to grab a towel, and your toothbrush.  Dashing to the car, you set your GPS to the meeting point.  Several messages come in from your friends: “on the way”, “c u there”, and “brains! lol”. In 20 minutes you'll be out of the city and with your friends... but then what?"
        
                page1?.pageChoiceA = page2
                page1?.pageChoiceB = page3
                page2?.pageChoiceA = page4
                page2?.pageChoiceB = page5
                page3?.pageChoiceA = page6
                page3?.pageChoiceB = page7
                
                currentPage = page1
    }

    
    @IBAction func actionButtonA(_ sender: UIBarButtonItem) {
        print("is actionButtonA working?");
        performSegue(withIdentifier: "showPageB" , sender: self.pageButtonA.title)
    }
    
    @IBAction func actionButtonB(_ sender: UIBarButtonItem) {
        print("is actionButtonB working?");
        performSegue(withIdentifier: "showPageB" , sender: self.pageButtonB.title)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        page_title.title = "Page \(currentPage!.pageNumber ?? 1)"
        pageButtonA.title = "Page \(currentPage!.pageChoiceA?.pageNumber ?? 0)"
        pageButtonB.title = "Page \(currentPage!.pageChoiceB?.pageNumber ?? 0)"
        page_text.text = currentPage?.pageText
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let pageB = segue.destination as? ViewController_B
        
        myPageButtonA = self.pageButtonA.title!
        
        if sender as? String == self.pageButtonA.title {
            print("choice A")
            print(myPageButtonA)
            pageB?.currentPage = currentPage?.pageChoiceA
        } else {
            print("choice B")
            print(myPageButtonB)
            pageB?.currentPage = currentPage?.pageChoiceB
        }
    }

}
