//
//  Page.swift
//  pickapath
//
//  Created by Christian Jurt on 2017-11-28.
//  Copyright © 2017 Christian Jurt. All rights reserved.
//

import Foundation

//class called "Page". This object will define a page of the story.
class Page {
    
    //properties needed
    //an Int called pageNumber
    //a String calle pageText
    //a Page object called pageChoiceA
    //a Page object called pageChoiceB
    
        var pageNumber: Int?
        var pageText: String?
        var pageChoiceA: Page?
        var pageChoiceB: Page?
    
    
}
