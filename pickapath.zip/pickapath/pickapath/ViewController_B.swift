//
//  ViewController_B.swift
//  pickapath
//
//  Created by Christian Jurt on 2017-11-28.
//  Copyright © 2017 Christian Jurt. All rights reserved.
//

import UIKit

class ViewController_B: UIViewController {
    
    @IBOutlet weak var page_title: UINavigationItem!
    @IBOutlet weak var pageButtonA: UIBarButtonItem!
    @IBOutlet weak var pageButtonB: UIBarButtonItem!
    @IBOutlet weak var page_text: UITextView!
    
        var currentPage: Page? = Page()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
                page_title.title = "Page \(currentPage!.pageNumber ?? 2)"
                pageButtonA.title = "Page \(currentPage!.pageChoiceA?.pageNumber ?? 0)"
                pageButtonB.title = "Page \(currentPage!.pageChoiceB?.pageNumber ?? 0)"
                page_text.text = currentPage?.pageText
            }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                let pageC = segue.destination as? ViewController_C
        
                if sender as? String == "Hello" {
                    pageC?.currentPage = currentPage?.pageChoiceA
                } else {
                    pageC?.currentPage = currentPage?.pageChoiceB
                }
            }
    
    @IBAction func actionButtonA(_ sender: Any) {
        performSegue(withIdentifier: "showPageC", sender: "Hello")
    }
    @IBAction func actionButtonB(_ sender: Any) {
        performSegue(withIdentifier: "showPageC", sender: self.pageButtonB)
    }
    
    

}
